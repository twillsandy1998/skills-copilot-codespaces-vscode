#define NULL 0
int main(){
   int *p=NULL;
   if (*p){
   
   }
   return 0;
}
