int main(){
    int x,y;
    x=y+1;
    return 0;
}
