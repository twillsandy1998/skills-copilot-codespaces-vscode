int main()
{
    int x;
    int y=10;
    int a[10];
    x=a[y];
    return 0;

}

