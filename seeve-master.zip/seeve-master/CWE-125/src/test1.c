int main()
{
 int a[10];
 a[10] = 0;
 return 0;
}
