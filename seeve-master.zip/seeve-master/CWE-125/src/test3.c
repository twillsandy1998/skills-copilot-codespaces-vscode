int main()
{
    int x;
    int y=10;
    int a[10];
    if (y)
    {
        x=a[y+2];
    }
    return 0;
}

