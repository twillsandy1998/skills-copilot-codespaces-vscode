int main()
{
    int y=10;
    int a[10];
    while (y>=0) 
    {   
        a[y]=y;
        y=y-1;
    }
    return 0;
}

