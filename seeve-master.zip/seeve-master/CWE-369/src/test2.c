int main()
{
    int x;
    int a[10];
    a[0]=0;
    x=1/a[0];
    return 0;
}
