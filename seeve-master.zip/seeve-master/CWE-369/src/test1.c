int main()
{
    int x;
    x=1/0;
    return 0;
}
