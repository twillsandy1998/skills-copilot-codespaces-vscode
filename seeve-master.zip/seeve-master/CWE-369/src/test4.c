int main()
{
    int x;
    int y=0;
    x=2/y;
    return 0;
}

