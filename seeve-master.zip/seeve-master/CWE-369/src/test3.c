int main()
{
    int x;
    int y=0;
    if (!y)
    {
        x=4/y;
    }
    return 0;
}

