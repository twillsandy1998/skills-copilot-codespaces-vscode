#include <stdio.h>
#include <string.h>
int main(){
    char str[20];
    strcat(str, "hello world");
    printf("%s", str);
    return 0;
}
