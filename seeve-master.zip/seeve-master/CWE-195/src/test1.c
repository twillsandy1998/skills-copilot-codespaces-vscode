
unsigned int amount(int y){ return y;}

int main(){
   int amoun;
   int value=-300;
   amoun=amount(value);
   return 0;
}
