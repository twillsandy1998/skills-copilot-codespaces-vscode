#include <stdio.h>
int main(){
    char last_name[20];
    printf ("Enter your last name: ");
    scanf ("%s", last_name);
    return 0;
}
